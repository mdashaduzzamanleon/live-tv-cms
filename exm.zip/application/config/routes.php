<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$route['default_controller'] 			= "home";
$route['404_override'] 					= 'notfound';
$route['watch/(:any)'] 					= 'watch/index/$1';
$route['watch/(:any)/(:any)'] 			= 'watch/index/$1/$2';
$route['watch/(:any)/(:any)/(:any)'] 	= 'watch/index/$1/$2/$3';
$route['blog/:num'] 					= 'blog/index';
$route['blog/category/(:any)'] 			= 'blog/category/$1';
$route['blog/(:any)'] 					= 'blog/details/$1';
$route['country/(:any)'] 				= 'country/index/$1';
$route['country/(:any)/:num'] 			= 'country/index/$1';
$route['genre/(:any)'] 					= 'genre/index/$1';
$route['genre/(:any)/:num'] 			= 'genre/index/$1';
$route['type/(:any)'] 					= 'type/index/$1';
$route['type/(:any)/:num'] 				= 'type/index/$1';
$route['request-movies'] 				= 'home/request_movies';
$route['contact-us'] 					= 'home/contact';
$route['send_message'] 					= 'home/send_message';
$route['contact_process'] 				= 'home/contact_process';
$route['send_movie_requiest'] 			= 'home/send_movie_requiest';
$route['search'] 						= 'home/search';
$route['movies'] 						= 'home/movies';
$route['movie/(:any)'] 					= 'movie/index/$1';
$route['all-movies'] 					= 'home/home2';
$route['tv-series'] 					= 'tvseries/home';
$route['tv-series/watch'] 				= 'tvseries/watch';
$route['tv-series/watch/(:any)'] 		= 'tvseries/watch/$1';
$route['live-tv'] 						= 'live_tv/index/$1';
$route['live-tv/(:any)'] 				= 'live_tv/watch/$1';
$route['about-us'] 						= 'page/about_us';
$route['request-movies'] 				= 'home/request_movies';
$route['privacy-policy'] 				= 'home/policy';
$route['trailers'] 						= 'home/trailers';
$route['request'] 						= 'home/request_for_movies';
$route['dmca'] 							= 'home/dmca';
$route['policy'] 						= 'home/policy';
$route['terms'] 						= 'home/terms';
$route['star/(:any)'] 					= 'star/index/$1';
$route['star/(:any)/:num'] 				= 'star/index/$1';
$route['director/(:any)'] 				= 'director/index/$1';
$route['director/(:any)/:num'] 			= 'director/index/$1';
$route['tags/(:any)'] 					= 'tags/index/$1';
$route['tags/(:any)/:num'] 				= 'tags/index/$1';
$route['year'] 							= 'year/find';
$route['year/(:any)'] 					= 'year/find/$1';
$route['year/(:any)/:num'] 				= 'year/find/$1';
$route['page/(:any)'] 					= 'page/index/$1';
$route['sitemap.xml'] 					= "home/sitemap";
$route['my-account/profile'] 			= 'user/profile';
$route['my-account/update'] 			= 'user/update_profile';
$route['my-account/favorite'] 			= 'user/favorite';
$route['my-account/change-password'] 	= 'user/change_password';
$route['my-account/watch-later'] 		= 'user/watch_later';


/* End of file routes.php */
/* Location: ./application/config/routes.php */